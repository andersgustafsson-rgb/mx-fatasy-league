Attribute VB_Name = "ModulTidrapport"
Option Explicit

' Kopiera inklistrat från «Klistra_in» till vald månadsflik (namn i B1).
' Så här använder du: Alt+F11 → Infoga modul → klistra in denna kod → Spara arbetsboken som .xlsm
' → Infoga former → knapp → tilldela makrot FlyttaTillValdManad.

Public Sub FlyttaTillValdManad()
    Const COL_LAST As Long = 16
    Const HDR_DEFAULT As Long = 8
    Dim wsK As Worksheet
    Dim wsM As Worksheet
    Dim mName As String
    Dim hdrRow As Long
    Dim lastR As Long
    Dim r As Long
    Dim c As Long
    Dim rng As Range
    Dim hdr As Variant

    On Error GoTo EH

    Set wsK = Worksheets("Klistra_in")

    mName = Trim$(CStr(wsK.Range("B1").Value))
    If Len(mName) = 0 Then
        MsgBox "Välj månad i cell B1 (listrutan) först.", vbExclamation, "Tidrapport"
        Exit Sub
    End If

    On Error Resume Next
    Set wsM = Worksheets(mName)
    On Error GoTo EH
    If wsM Is Nothing Then
        MsgBox "Det finns ingen flik som heter """ & mName & """. Kontrollera stavning i B1 (t.ex. Mars, Februari).", vbExclamation, "Tidrapport"
        Exit Sub
    End If

    hdrRow = 0
    For r = 5 To 120
        If StrComp(Trim$(CStr(wsK.Cells(r, 1).Value)), "Namn", vbTextCompare) = 0 Then
            hdrRow = r
            Exit For
        End If
    Next r
    If hdrRow = 0 Then hdrRow = HDR_DEFAULT

    lastR = wsK.Cells(wsK.Rows.Count, 1).End(xlUp).Row
    If lastR <= hdrRow Then
        MsgBox "Inga datarader hittades under rubrikraden (kolumn A tom). Klistra in tabellen först.", vbInformation, "Tidrapport"
        Exit Sub
    End If

    Set rng = wsK.Range(wsK.Cells(hdrRow, 1), wsK.Cells(lastR, COL_LAST))

    Application.ScreenUpdating = False
    wsM.Cells.Clear
    rng.Copy Destination:=wsM.Range("A1")
    Application.CutCopyMode = False

    ' Töm klistret men lämna B1 och rubrikrad 8
    If lastR > hdrRow Then
        wsK.Range(wsK.Cells(hdrRow + 1, 1), wsK.Cells(lastR, COL_LAST)).ClearContents
    End If

    hdr = Split("Namn;Datum;Kl Fom;Kl Tom;Kl rast;Rast;Typ;Orsak;Bemanningstyp;Proc;Organisation;Kto;Tst;Bev;Bvä;Med", ";")
    For c = 1 To COL_LAST
        With wsK.Cells(HDR_DEFAULT, c)
            .Value = hdr(c - 1)
            .Font.Bold = True
        End With
    Next c

    Application.ScreenUpdating = True

    MsgBox "Klart: data kopierades till fliken «" & mName & "».", vbInformation, "Tidrapport"
    Exit Sub

EH:
    Application.ScreenUpdating = True
    MsgBox "Fel " & CStr(Err.Number) & ": " & Err.Description, vbCritical, "Tidrapport"
End Sub
